#!/usr/bin/python
# -*- coding:utf-8 -*-
import os
from agents.base_agent import BaseAgent
from datetime import datetime

FALLBACK_INTERPRETATION = (
    "  井斜角增加导致井轨迹更陡，穿过地层的真厚度略微减小。\n"
    "  建议在实钻中控制井斜角在25-30度范围内以保持地层对比准确性。"
)

class ReportAgent(BaseAgent):
    def execute(self, context):
        original = context["thickness"]
        sensitivity = context.get("thickness_sensitivity", [])
        delta = context.get("sensitivity_delta", 5)
        report_lines = []
        report_lines.append("=== 多Agent地质导向分析报告 ===")
        report_lines.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append("\n【原始地层真厚度】")
        for r in original:
            report_lines.append(f"  {r['地层名称']}: {r['真厚度(米)']} 米")
        if sensitivity:
            report_lines.append(f"\n【敏感性分析】（井斜角增加 {delta}°）")
            for r in sensitivity:
                report_lines.append(f"  {r['地层名称']}: {r['真厚度(米)']} 米")
            report_lines.append("\n【智能解读】")
            report_lines.append(self._llm_interpret(original, sensitivity, delta))
        else:
            report_lines.append("\n【提示】未进行敏感性分析，可调整参数后重新运行。")
        context["report"] = "\n".join(report_lines)
        context["report_status"] = "完成"
        return context

    def _llm_interpret(self, original, sensitivity, delta):
        api_key = os.environ.get("LLM_API_KEY", "ollama")
        base_url = os.environ.get("LLM_BASE_URL", "http://127.0.0.1:11434/v1")
        model = os.environ.get("LLM_MODEL", "qwen2.5:7b")
        if not api_key:
            return "[规则回退]\n" + FALLBACK_INTERPRETATION
        orig_lines = "\n".join(f"- {r['地层名称']}: {r['真厚度(米)']} 米" for r in original)
        sens_lines = "\n".join(f"- {r['地层名称']}: {r['真厚度(米)']} 米" for r in sensitivity)
        prompt = (
            "你是石油钻井地质导向专家。基于以下数据，用中文输出2-4条简洁专业的解读与实钻建议：\n"
            f"原始地层真厚度：\n{orig_lines}\n\n"
            f"井斜角增加{delta}°后地层真厚度：\n{sens_lines}\n\n"
            "请直接输出结论，不要重复数据，不要使用Markdown标题。"
        )
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key, base_url=base_url)
            resp = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
            )
            text = resp.choices[0].message.content.strip()
            return f"[LLM生成: {model}]\n" + "\n".join("  " + line for line in text.splitlines())
        except Exception as e:
            return f"[规则回退: {type(e).__name__}]\n" + FALLBACK_INTERPRETATION
